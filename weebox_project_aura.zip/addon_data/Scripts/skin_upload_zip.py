import shutil

# COPIE DES DOSSIERS, FICHIERS DU SKIN & SCRIPTS

source_dir = xbmc.translatePath('special://home/userdata/addon_data/skin.project.aura')
destination_dir = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/addon_data/skin.project.aura')

source_dir1 = xbmc.translatePath('special://home/userdata/addon_data/script.skinshortcuts')
destination_dir1 = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/addon_data/script.skinshortcuts')

source_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura/1080i/script-skinshortcuts-includes.xml')
destination_dir2 = xbmc.translatePath('special://home/userdata/addon_data/Scripts/addons/skin.project.aura/1080i/script-skinshortcuts-includes.xml')

source_dir3 = xbmc.translatePath('special://home/userdata/addon_data/Scripts')
destination_dir3 = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/addon_data/Scripts')

shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
shutil.copytree(source_dir1, destination_dir1, dirs_exist_ok=True)
shutil.copytree(source_dir3, destination_dir3, dirs_exist_ok=True)
shutil.copy(source_dir2, destination_dir2)

# CREATION ARCHIVE ZIP

shutil.make_archive(xbmc.translatePath('special://home/userdata/Scripts/weebox_project_aura'),'zip',xbmc.translatePath('special://home/userdata/Scripts/Skin_save'))
xbmc.executebuiltin("Notification(SKIN SAUVEGARDE, Archive ZIP créée !)")