#!/usr/bin/python3
xbmc.executebuiltin("Notification(FICHIER TEMP,Effacement en cours...)")
import shutil
dirPath = xbmc.translatePath('special://home/temp/temp/');
# Delete all contents of a directory using shutil.rmtree() and  handle exceptions
try:
   shutil.rmtree(dirPath)
except:
   print('Error while deleting directory')
xbmc.executebuiltin("Notification(PACK PAGE SKIN RAYFLIX,Téléchargement en cours...)")
from io import BytesIO
from urllib.request import urlopen
from zipfile import ZipFile
zipurl = 'https://github.com/osmoze06/skin_pack/raw/main/weebox_project_aura.zip'
with urlopen(zipurl) as zipresp:
    with ZipFile(BytesIO(zipresp.read())) as zfile:
        zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))
import shutil
source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
source_dir2 = xbmc.translatePath('special://home/temp/temp/addons/skin.project.aura')
destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
xbmc.executebuiltin("Notification(TELECHARGEMENT OK,Mise à jour effectuée !)")
xbmc.sleep(5000)
xbmc.executebuiltin("Notification(ACTUALISATION DU SKIN, Page Skin Rayflix...)")
xbmc.sleep(2000)
xbmc.executebuiltin('ReloadSkin')